import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.*;
import java.io.*;
import java.net.Socket;
import java.security.KeyStore;
import java.security.cert.*;

/**
 * Copyright [2017] [Yahya Hassanzadeh-Nazarabadi]

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

/**
 * This class handles and establishes an SSL connection to a server
 */
public class SSLConnectToServer
{
    /*
    Name of key store file
     */
    private final String KEY_STORE_NAME =  "clientkeystore";
    /*
    Password to the key store file
     */
    private final String KEY_STORE_PASSWORD = "storepass";
    private SSLSocketFactory sslSocketFactory;
    private SSLSocket sslSocket;
    private BufferedReader is;
    private PrintWriter os;

    protected String serverAddress;
    protected int serverPort;
    protected int serverPortTCP; // For connecting to TCP channel

    /***
     * Constructor of the connection handling class of the Client, SSLConnectToServer.
     * Keystore operations,assigning the essentials, are done in the body, after the address and port numbers are assigned. However,
     * Creating the key store is excluded from that part, since the certificate will be taken through the TCP connection.
     * @param address
     * @param portTLS
     * @param portTCP
     * @throws Exception
     */
    public SSLConnectToServer(String address, int portTLS,int portTCP) throws Exception
    {

        serverAddress = address;
        serverPort = portTLS;
        serverPortTCP=portTCP;
        /*
        Loads the keystore's address of client
         */
        System.setProperty("javax.net.ssl.trustStore", KEY_STORE_NAME);
        // Loads the keystore's password of client
        System.setProperty("javax.net.ssl.trustStorePassword", KEY_STORE_PASSWORD);
        // Load the certificates in the key store
        //Create_Key_Store();
    }

    /***
     * Both connection through TCP and SSl is implemented in the Connect function. First, the TCP connection is observed and
     * username and password are sent to server. Followingly, it takes a input from user, which indicates the verification. From that
     * input, whether the connection processes is aborted or the certificate is taken from the server. After having the certificate,
     * TCP connection is aborted and key is generated. Subsequently, with the key, SSL connection is observed.
     * @param name
     * @param password
     * @throws Exception
     */
    public void Connect(String name, String password) throws Exception {

        //Connecting through TCP
        System.out.println("Connecting");
        Socket sTCP=new Socket(serverAddress, serverPortTCP);
        System.out.println("Connected TCP channel");
        PrintWriter osTCP= new PrintWriter(sTCP.getOutputStream());
        osTCP.println(name);
        osTCP.flush();
        osTCP.println(password);
        osTCP.flush();
        BufferedReader isTCP=new BufferedReader(new InputStreamReader(sTCP.getInputStream()));
        String res= isTCP.readLine();
        System.out.println(res);
        if(res.equals("true")){
            certTransfer(sTCP);
            System.out.println("Certificate is taken");
        }
        else{
            sTCP.close();
            osTCP.close();
            isTCP.close();
            return;
        }
        sTCP.close();
        osTCP.close();
        isTCP.close();

        Create_Key_Store();

        try
            {
                sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
                sslSocket = (SSLSocket) sslSocketFactory.createSocket(serverAddress, serverPort);
                sslSocket.startHandshake();
                is=new BufferedReader(new InputStreamReader(sslSocket.getInputStream()));
                os= new PrintWriter(sslSocket.getOutputStream());
                System.out.println("Successfully connected to " + serverAddress + " on port " + serverPort);
            }
        catch (Exception e)
            {
                e.printStackTrace();
            }
    }

    /***
     * In this function, certificate is taken in byte wise contex and written in a file named as server_crt.crt.
     * It takes a socket as an input to indicate the connection socket.
     * @param s
     */
    public void certTransfer(Socket s){
        byte[] contents = new byte[1000];
        try {
            BufferedOutputStream osTcp = new BufferedOutputStream(new FileOutputStream("server_crt.crt"));
            InputStream isTcp = s.getInputStream();
            int readBytes = 0;
            while((readBytes = isTcp.read(contents)) != -1){
                osTcp.write(contents, 0, readBytes);
            }
            osTcp.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Disconnects form the specified server
     */
    public void Disconnect()
    {
        try
            {
                is.close();
                os.close();
                sslSocket.close();
            }
        catch (IOException e)
            {
                e.printStackTrace();
            }
    }

    /***
     * SendForAnswer function manupulated in the sense that it only reads from the pipeline.
     * @return
     */
    public String SendForAnswer()
    {
        String response = new String();
        try
        {
            //os.println(message);
            //os.flush();
            response = is.readLine();
        }
        catch(IOException e)
        {
            e.printStackTrace();
            System.out.println("ConnectionToServer. SendForAnswer. Socket read Error");
        }
        return response;
    }

    /***
     * As the input is taken as a complicated manner, this function reads the pipeline and observes a meaningful message
     * from those three char messages.
     * @param msg
     * @return
     */
    public static String[] ParseAnswer(String msg) {

        String a1="";
        String a2="";
        String a3="";
        String[] resArray = {a1,a2,a3};
        int index=0;
        for (int i=0; i<msg.length();i++){
            index=index%3;
            if(msg.charAt(i)!='$'){
                resArray[index]+=msg.charAt(i);
            }
            index+=1;
        }
        return resArray;
    }

    public void Create_Key_Store() throws Exception{

        // Create keystore instance
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());

        // Load the empty keystore
        ks.load(null, null);

        // Initialize the certificate factory
        CertificateFactory cf = CertificateFactory.getInstance("X.509");

        // Load the certificate
        InputStream caInput = new BufferedInputStream(new FileInputStream(new File("server_crt.crt")));

        Certificate ca;
        try {
            ca = cf.generateCertificate(caInput);
            // System.out.println("ca=" + ((X509Certificate) ca).getSubjectDN());
        } finally {
            caInput.close();
        }

        // Create the certificate entry
        ks.setCertificateEntry("ca", ca);

        // Write the file back
        ks.store(new FileOutputStream("clientkeystore"), KEY_STORE_PASSWORD.toCharArray());

    }


}
