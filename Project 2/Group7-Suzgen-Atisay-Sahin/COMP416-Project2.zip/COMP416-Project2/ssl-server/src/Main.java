/**
 * Copyright [2017] [Yahya Hassanzadeh-Nazarabadi]

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

/***
 * Main body of the Server program. To have multiple port listening, two server types is constructed, TCP and SSl. TCPServer is written as
 * thread and so, Main body holds the SSLServer.
 */
public class Main
{
    public static void main(String args[])
    {

        TCPServer sT= new TCPServer(53590);
        sT.start();
        System.out.println("TCP server is running");
        SSLServer s = new SSLServer(4444);
        System.out.println("SSL server is running");

    }

}
