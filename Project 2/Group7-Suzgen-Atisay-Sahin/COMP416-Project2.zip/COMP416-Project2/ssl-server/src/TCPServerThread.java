import java.io.*;
import java.net.Socket;

class TCPServerThread extends Thread
{
    protected BufferedReader is;
    protected PrintWriter os;


    protected BufferedInputStream isC;
    protected OutputStream osC;

    protected Socket s;
    private String line = new String();


    /**
     * Creates a server thread on the input socket
     *
     * @param s input socket to create a thread on
     */
    public TCPServerThread(Socket s)
    {
        this.s = s;
    }

    /**
     * The body of the thread. First, certificate file is opened and user profile is taken from the pipeline.
     * From that profile, it is checked whether the user is verified user or not. For this purpose, user.txt file
     * that holds the predefined profiles is created. If the user is not verified, connection aborted. The result of the verification
     * processes is sent to client also. Followingly, certificate is sent to the client. In the and, TCP connection with client ends.
     */
    public void run()
    {
        File crtFile= new File("server_crt.crt");
        try
        {
            is = new BufferedReader(new InputStreamReader(s.getInputStream()));
            os = new PrintWriter(s.getOutputStream());
            osC = s.getOutputStream();
        }
        catch (IOException e)
        {
            System.err.println("Server.Master.Master.Server Thread. Run. IO error in server thread");
        }
        try
        {
            String name= is.readLine();
            System.out.println(name);
            String password= is.readLine();
            System.out.println(password);
            boolean verif=checkVerif(name, password);
            os.println(verif);
            os.flush();
            System.out.println(verif);
            if(!verif) return;
            isC=new BufferedInputStream(new FileInputStream(crtFile));
            byte[] contents;
            long current=0;
            long fileSize= crtFile.length();
            while (current!=fileSize){
                int size=1000;
                if(fileSize-current>=size){
                    current+=size;
                } else{
                    size=(int) (fileSize-current);
                    current=fileSize;
                }
                contents=new byte[size];
                isC.read(contents);
                osC.write(contents);
            }
            osC.flush();

        }
        catch (IOException e)
        {
            line = this.getName(); //reused String line for getting thread name
            System.err.println("Server.Master.Master.Server Thread. Run. IO Error/ Client " + line + " terminated abruptly");
        }

        catch (NullPointerException e)
        {
            line = this.getName(); //reused String line for getting thread name
            System.err.println("Server.Master.Master.Server Thread. Run.Client " + line + " Closed");
        } finally
        {
            try
            {
                System.out.println("Closing the connection");
                if (is != null)
                {
                    is.close();
                    System.err.println(" Socket Input Stream Closed");
                }

                if (os != null)
                {
                    os.close();
                    System.err.println("Socket Out Closed");
                }
                if (s != null)
                {
                    s.close();
                    System.err.println("Socket Closed");
                }

            }
            catch (IOException ie)
            {
                System.err.println("Socket Close Error");
            }
        }//end finally


    }

    private boolean checkVerif(String name, String password) throws IOException {
        boolean verif=false;
        File file=new File("users.txt");    //creates a new file instance
        FileReader fr=new FileReader(file);   //reads the file
        BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream
        while((line=br.readLine())!=null)
        {
            String[] user= line.split(":");
            if(user[0].equals(name)&&user[1].substring(1).equals(password))verif=true;
            System.out.println(line);
        }
        fr.close();    //closes the stream and release the resources
        return verif;
    }

}