import java.io.IOException;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;

public class TCPServer extends Thread{
    private ServerSocket serverSocketC;
    public static final int DEFAULT_SERVER_PORT = 53590;

    /***
     * This is the constructor of the TCPServer. It takes the port that is wanted to be listened as a parameter.
     * And creates server socket on that port.
     * @param portC
     */
    public TCPServer(int portC)
    {
        try
        {
            serverSocketC = new ServerSocket(portC);
            System.out.println("Opened up a server socket on " + Inet4Address.getLocalHost());
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.err.println("Server.Master.Master.Server class.Constructor exception on opening a server socket");
        }
        /*
        while (true)

        {
            ListenAndAccept();
        }

         */
    }

    /***
     * Run function of the thread. TCPServer listens the port in that part.
     */
    public void run() {

        while (true)
        {
            ListenAndAccept();
        }
    }

    /***
     * Basic ListenAndAccept function taken from our previous project. Server listens the port 53590 and creates another thread for handling
     * with the clients in case of connection.
     */
    private void ListenAndAccept()
    {
        Socket sc;
        try
        {

            sc = serverSocketC.accept();
            System.out.println(sc.getPort());
            System.out.println("A connection was established with a client on the address of " + sc.getRemoteSocketAddress());
            TCPServerThread st = new TCPServerThread(sc);
            st.start();

        }

        catch (Exception e)
        {
            e.printStackTrace();
            System.err.println("Server.Master.Master.Server Class.Connection establishment error inside listen and accept function");
        }
    }



}
